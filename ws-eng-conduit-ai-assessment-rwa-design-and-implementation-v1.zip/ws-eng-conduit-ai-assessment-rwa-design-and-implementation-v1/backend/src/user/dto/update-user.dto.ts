export class UpdateUserDto {
  readonly bio: string;
  readonly email: string;
  readonly image: string;
  readonly username: string;
}
