export class CreateCommentDto {
  readonly body: string;
}
