export const SECRET = 'secret-key';
