export default {
  baseApiUrl: '/api/',
};
